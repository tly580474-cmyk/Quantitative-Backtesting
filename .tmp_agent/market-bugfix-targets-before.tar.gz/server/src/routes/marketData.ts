import type { FastifyInstance } from 'fastify';
import type { Pool } from 'mysql2/promise';
import { z } from 'zod';
import type { EnvConfig } from '../config.js';
import { ErrorCodes, apiError, dbUnavailable } from '../validation/errors.js';
import {
  getDailyCandles,
  getDataFreshness,
  getHistoryDailyBars,
  getLatestStockValuation,
  getPublishedHistoryAdjustment,
} from '../marketData/repositories/marketDataRepository.js';
import {
  applyHistoryAdjustment,
  type HistoryAdjustmentMode,
} from '../marketData/normalization/historyAdjustment.js';
import { listProviders } from '../marketData/providers/providerRegistry.js';
import { getInstrument } from '../marketData/repositories/instrumentRepository.js';
import {
  fetchResearchReports,
  fetchCachedMarketSentimentOverview,
  fetchMarketTechnicalRows,
  fetchMarketTechnicalRowsFromDb,
  fetchStockKlineFromDb,
  fetchStockFullHistoryFromDb,
  fetchMarketIndexQuotes,
  fetchWatchlistQuote,
  readWatchlistTradingDateEvidence,
  fetchStockIntraday,
  fetchStockKline,
  fetchStockQuote,
  inferType,
  resolveSecurity,
  searchStocks,
} from '../marketData/aStockDataService.js';
import {
  aggregateDailyKlines,
  mergeKlinePoints,
  shouldRefreshDailyKline,
} from '../marketData/hybridKline.js';
import { getChinaMarketSession } from '../marketData/jobs/marketSession.js';
import {
  analyzeHistoricalTechnicals,
  filterEnrichedCandidates,
  prefilterMarketTechnicalRows,
  type HistoricalTechnicalIndicators,
  type MarketTechnicalCandidate,
} from '../marketData/marketTechnicalScreen.js';
import { tencentProvider } from '../marketData/providers/tencentProvider.js';
import { updateIndexDatasets } from '../marketData/jobs/indexDatasetUpdater.js';
import {
  StockResearchAgent,
  TRADING_STYLE_DEFINITIONS,
  TRADING_STYLE_IDS,
} from '../services/stockResearchAgent.js';
import {
  MarketOpinionAgent,
  MARKET_OPINION_TIERS,
  selectOpinionNews,
} from '../services/marketOpinionAgent.js';
import {
  buildMarketContext,
  type MarketOpinionPushService,
} from '../services/marketOpinionPushService.js';
import { fetchSevenLayerSection, fetchSevenLayerSnapshot } from '../marketData/sevenLayerDataService.js';
import { extractSelectionScoreContext } from '../marketData/selectionScoreContext.js';
import { fetchCachedHotSectors, fetchSectorConstituents } from '../marketData/hotSectorService.js';
import { fetchCninfoAnnouncements, type MainlandMarket } from '../marketData/http/cninfoClient.js';
import { buildCanonicalNewsHash } from '../marketData/marketNewsDedup.js';
import type { MarketNewsItem } from '../marketData/marketNewsTypes.js';
import { listMarketNews } from '../marketData/repositories/marketNewsRepository.js';
import type { HistoryReadMode } from '../marketData/repositories/historyStorePolicy.js';
import {
  getCurrentResearchSnapshot,
  queryResearchSnapshot,
  queryStockDividendHistory,
  queryLatestIndexConstituents,
} from '../research/duckdbResearchService.js';
import { buildResearchSnapshot } from '../research/snapshotBuilder.js';
import { getResearchSnapshotFreshness } from '../research/snapshotFreshness.js';
import { verifyCurrentResearchSnapshot } from '../research/snapshotVerifier.js';
import { getMinuteDataCatalog, queryMinuteBars } from '../minuteData/minuteDataService.js';
import { getMarketBillboard, getStockBillboard } from '../marketData/dragonTigerService.js';
import { getMarketNews, getMarketOpinionNews, getStockNews } from '../marketData/marketNewsService.js';
import { getFactorSelectionHistory } from '../marketData/factorStockSelection.js';
import { getCsi1000LowPbSelectionHistory } from '../marketData/csi1000LowPbSelection.js';
import { getMarketHealthOverview } from '../marketHealth/service.js';
import { getWatchlistSession } from '../marketData/watchlistSession.js';

const candlesQuerySchema = z.object({
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  adjustmentMode: z.enum(['none', 'qfq', 'hfq']).default('none'),
  offset: z.coerce.number().int().min(0).default(0),
  limit: z.coerce.number().int().min(1).max(5000).default(5000),
});

const candidateIndicatorCache = new Map<string, { data: HistoricalTechnicalIndicators | null; cachedAt: number }>();

type TradingLayerKey = 'signal' | 'capital' | 'fundamental';

async function loadTradingLayer(code: string, key: TradingLayerKey): Promise<Record<string, unknown>> {
  try {
    const section = await fetchSevenLayerSection(code, key);
    return {
      status: section.status,
      summary: section.summary,
      sources: section.sources,
      records: section.records.slice(0, 12).map((record) => ({
        source: record.source,
        title: record.title,
        date: record.date,
        summary: record.summary,
        metrics: record.metrics,
      })),
      errors: section.errors,
    };
  } catch (error) {
    return {
      status: 'degraded',
      records: [],
      errors: [error instanceof Error ? error.message : String(error)],
    };
  }
}

function emptyTradingLayer(reason: string): Record<string, unknown> {
  return {
    status: 'not_requested',
    records: [],
    errors: [],
    summary: reason,
  };
}

async function loadLocalDividendLayer(
  snapshotRoot: string,
  code: string,
  price: number | null,
  now: Date,
): Promise<Record<string, unknown>> {
  try {
    const events = await queryStockDividendHistory(snapshotRoot, code, 30);
    const cutoff = now.getTime() - 366 * 86_400_000;
    const completed = events.filter((event) => {
      const exDate = typeof event.exDate === 'string' ? Date.parse(`${event.exDate}T00:00:00+08:00`) : Number.NaN;
      return Number.isFinite(exDate) && exDate >= cutoff && exDate <= now.getTime();
    });
    const trailingCashDividendPerShare = completed.reduce((sum, event) => {
      const value = Number(event.cashDividendPerShare);
      return sum + (Number.isFinite(value) && value > 0 ? value : 0);
    }, 0);
    const dividendYield = price && price > 0 && trailingCashDividendPerShare > 0
      ? Math.round((trailingCashDividendPerShare / price) * 10_000) / 100
      : null;
    return {
      status: events.length ? 'ok' : 'no_data',
      summary: events.length
        ? `本地研究快照返回 ${events.length} 条分红事件`
        : '本地研究快照暂无该股票分红事件',
      sources: ['本地研究快照（分红事件）'],
      records: [{
        source: '本地研究快照（分红事件）',
        title: '近12个月股息率与分红历史',
        date: now.toISOString().slice(0, 10),
        metrics: {
          dividendYield,
          dividendYieldMethod: '近12个月已除权现金分红合计 ÷ 当前股价',
          trailingCashDividendPerShare: Math.round(trailingCashDividendPerShare * 10_000) / 10_000,
          completedDividendCount: completed.length,
          historyEventCount: events.length,
        },
      }, ...events.slice(0, 10).map((event) => ({
        source: '本地研究快照（分红事件）',
        title: String(event.rawPlan ?? event.planStatus ?? '分红事件'),
        date: String(event.exDate ?? event.latestAnnouncementDate ?? event.reportPeriod ?? '').slice(0, 10),
        metrics: event,
      }))],
      errors: [],
    };
  } catch (error) {
    return {
      status: 'degraded',
      summary: '本地分红快照读取失败',
      records: [],
      errors: [error instanceof Error ? error.message : String(error)],
    };
  }
}

function mergeTradingLayers(
  primary: Record<string, unknown>,
  fallback: Record<string, unknown>,
): Record<string, unknown> {
  const primaryRecords = Array.isArray(primary.records) ? primary.records : [];
  const fallbackRecords = Array.isArray(fallback.records) ? fallback.records : [];
  const errors = [
    ...(Array.isArray(primary.errors) ? primary.errors : []),
    ...(Array.isArray(fallback.errors) ? fallback.errors : []),
  ];
  return {
    status: primaryRecords.length || fallbackRecords.length ? (errors.length ? 'partial' : 'ok') : 'degraded',
    summary: [primary.summary, fallback.summary].filter((item) => typeof item === 'string').join('；'),
    sources: [
      ...(Array.isArray(primary.sources) ? primary.sources : []),
      ...(Array.isArray(fallback.sources) ? fallback.sources : []),
    ],
    records: [...primaryRecords, ...fallbackRecords],
    errors,
  };
}

async function loadRecentStockNews(code: string, dbOnline: boolean, now: Date) {
  let items: MarketNewsItem[] = [];
  try {
    const announcements = await fetchCninfoAnnouncements(code, mainlandMarket(code), 20);
    items = announcements.map((item) => ({
      newsId: item.id || `${code}-${item.publishedAt}-${item.title}`,
      sourceKey: 'cninfo',
      sourceName: '巨潮资讯',
      sourceTier: 'official',
      contentType: 'announcement',
      sourceUrl: item.url,
      title: item.title,
      publishedAt: item.publishedAt,
      securityCode: code,
      securityName: item.name || undefined,
      canonicalHash: buildCanonicalNewsHash(item.title, item.publishedAt),
      raw: item.raw,
    }));
  } catch {
    if (dbOnline) {
      items = await listMarketNews({ limit: 20, securityCode: code }).catch(() => []);
    }
  }
  return items
    .filter((item) => item.sourceTier !== 'self_media')
    .filter((item) => isRecentNews(item.publishedAt, now, 30))
    .slice(0, 10);
}

function mainlandMarket(code: string): MainlandMarket {
  if (/^(4|8|92)/.test(code)) return 'BJ';
  return /^6/.test(code) ? 'SH' : 'SZ';
}

async function loadOptionalResearchReports(code: string) {
  try {
    return await fetchResearchReports(code, 12);
  } catch {
    return [];
  }
}

async function loadLocalMarketNews(dbOnline: boolean, now: Date): Promise<MarketNewsItem[]> {
  if (!dbOnline) return [];
  try {
    return await getMarketOpinionNews(now.getTime(), 72);
  } catch {
    return [];
  }
}

const CANDIDATE_INDICATOR_CACHE_MS = 30 * 60_000;

async function enrichTechnicalCandidates(
  candidates: MarketTechnicalCandidate[],
  mode: 'realtime' | 'close' = 'realtime',
): Promise<MarketTechnicalCandidate[]> {
  const result = [...candidates];
  let cursor = 0;
  const workers = Array.from({ length: Math.min(12, result.length) }, async () => {
    while (cursor < result.length) {
      const index = cursor++;
      const candidate = result[index];
      const cached = candidateIndicatorCache.get(candidate.code);
      if (cached && Date.now() - cached.cachedAt < CANDIDATE_INDICATOR_CACHE_MS) {
        result[index] = { ...candidate, indicators: cached.data };
        continue;
      }
      try {
        const klines = mode === 'close'
          ? await fetchStockKlineFromDb(candidate.code, 'day', 120)
          : await fetchStockKline(candidate.code, 'day', 120);
        const indicators = analyzeHistoricalTechnicals(klines);
        candidateIndicatorCache.set(candidate.code, { data: indicators, cachedAt: Date.now() });
        result[index] = { ...candidate, indicators };
      } catch {
        candidateIndicatorCache.set(candidate.code, { data: null, cachedAt: Date.now() });
        result[index] = { ...candidate, indicators: null };
      }
    }
  });
  await Promise.all(workers);
  return result;
}

interface ResearchAgentConfig {
  apiKey: string;
  baseURL: string;
  model: string;
  timeoutMs: number;
  availableModels: string[];
}

export function registerMarketDataRoutes(
  app: FastifyInstance,
  dbOnline: boolean,
  agentConfig: ResearchAgentConfig,
  storageConfig: {
    historyReadMode: HistoryReadMode;
    snapshotRoot: string;
    minuteDataRoot: string;
    minuteQueryMaxRows: number;
    researchQueryMaxRows: number;
    pool?: Pool;
    config?: EnvConfig;
  } = {
    historyReadMode: 'prefer-v2',
    snapshotRoot: './data/research-snapshots',
    minuteDataRoot: './data/minute-data',
    minuteQueryMaxRows: 100000,
    researchQueryMaxRows: 10000,
  },
  opinionPushService?: MarketOpinionPushService,
): void {
  const agent = new StockResearchAgent(
    agentConfig.apiKey,
    agentConfig.baseURL,
    agentConfig.model,
    agentConfig.timeoutMs,
  );
  const opinionAgent = new MarketOpinionAgent(
    agentConfig.apiKey,
    agentConfig.baseURL,
    agentConfig.model,
    agentConfig.timeoutMs,
  );
  let snapshotUpdateInFlight: Promise<unknown> | null = null;

  // These endpoints fetch public market data on demand and intentionally do not depend on MySQL.
  app.get('/api/market-data/watchlist-session', async (req, reply) => {
    try {
      return reply.send(await getWatchlistSession(new Date(), undefined, readWatchlistTradingDateEvidence));
    } catch (error) {
      req.log.error(error);
      return reply.status(503).send({ message: '交易时段暂时不可用，请稍后重试' });
    }
  });

  app.get('/api/market-data/stocks/search', async (req, reply) => {
    const query = z.object({ q: z.string().trim().min(1).max(40) }).safeParse(req.query);
    if (!query.success) return reply.status(400).send({ message: '请输入股票代码、简称或拼音' });
    try {
      return reply.send({ items: await searchStocks(query.data.q) });
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: '股票搜索暂时不可用，请稍后重试' });
    }
  });

  app.get<{ Params: { code: string }; Querystring: { profile?: string; snapshot?: string } }>('/api/market-data/stocks/:code/quote', async (req, reply) => {
    const query = z.object({
      profile: z.enum(['true', 'false']).optional(),
      snapshot: z.enum(['live', 'close']).default('live'),
    }).safeParse(req.query);
    if (!query.success) return reply.status(400).send({ message: '行情查询参数无效' });
    try {
      const quote = query.data.snapshot === 'close'
        ? await fetchWatchlistQuote(req.params.code, 'close')
        : await fetchStockQuote(req.params.code, query.data.profile !== 'false');
      return reply.send(quote);
    } catch (error) {
      return reply.status(502).send({ message: error instanceof Error ? error.message : '行情获取失败' });
    }
  });

  app.get<{ Querystring: { snapshot?: string } }>('/api/market-data/indices/quotes', async (req, reply) => {
    const query = z.object({ snapshot: z.enum(['live', 'close']).default('live') }).safeParse(req.query);
    if (!query.success) return reply.status(400).send({ message: '指数行情查询参数无效' });
    try {
      return reply.send({ items: await fetchMarketIndexQuotes({ snapshot: query.data.snapshot }) });
    } catch (error) {
      return reply.status(502).send({ message: error instanceof Error ? error.message : '大盘行情获取失败' });
    }
  });

  app.get<{ Querystring: { force?: string } }>('/api/market-data/market-sentiment', async (req, reply) => {
    try {
      return reply.send(await fetchCachedMarketSentimentOverview(req.query.force === 'true'));
    } catch (error) {
      return reply.status(502).send({ message: error instanceof Error ? error.message : '市场情绪获取失败' });
    }
  });

  app.get<{ Querystring: { force?: string } }>('/api/market-data/market-health', async (req, reply) => {
    if (!dbOnline) return reply.status(503).send(dbUnavailable());
    try {
      return reply.send(await getMarketHealthOverview(req.query.force === 'true'));
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '大盘健康度获取失败' });
    }
  });

  app.get<{ Querystring: { force?: string } }>('/api/market-data/hot-sectors', async (req, reply) => {
    try {
      return reply.send(await fetchCachedHotSectors(req.query.force === 'true'));
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '热门板块获取失败' });
    }
  });

  app.get('/api/market-data/dragon-tiger/market', async (req, reply) => {
    const query = z.object({
      date: z.string().date().optional(),
      force: z.enum(['true', 'false']).default('false'),
    }).safeParse(req.query);
    if (!query.success) return reply.status(400).send({ message: '龙虎榜查询参数无效' });
    try {
      return reply.send(await getMarketBillboard({ date: query.data.date, force: query.data.force === 'true', dbOnline }));
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '龙虎榜获取失败' });
    }
  });

  app.get<{ Params: { code: string } }>('/api/market-data/dragon-tiger/stocks/:code', async (req, reply) => {
    const input = z.object({ code: z.string().regex(/\d{6}/), force: z.enum(['true', 'false']).default('false') })
      .safeParse({ ...req.params, ...(req.query as object) });
    if (!input.success) return reply.status(400).send({ message: '股票代码格式不正确' });
    try {
      return reply.send(await getStockBillboard(input.data.code, { force: input.data.force === 'true', dbOnline }));
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '个股龙虎榜获取失败' });
    }
  });

  app.get('/api/market-data/news/market', async (req, reply) => {
    const query = z.object({
      tier: z.enum(['official', 'state_media', 'professional', 'aggregator', 'self_media']).optional(),
      limit: z.coerce.number().int().min(1).max(100).default(20),
      before: z.string().datetime({ offset: true }).optional(),
      beforeId: z.coerce.number().int().positive().optional(),
      force: z.enum(['true', 'false']).default('false'),
    }).safeParse(req.query);
    if (!query.success) return reply.status(400).send({ message: '市场资讯查询参数无效' });
    try {
      return reply.send(await getMarketNews({
        tier: query.data.tier,
        limit: query.data.limit,
        before: query.data.before,
        beforeId: query.data.beforeId,
        force: query.data.force === 'true',
        dbOnline,
      }));
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '市场资讯获取失败' });
    }
  });

  app.get<{ Params: { code: string } }>('/api/market-data/news/stocks/:code', async (req, reply) => {
    const query = z.object({
      code: z.string().regex(/\d{6}/),
      limit: z.coerce.number().int().min(1).max(100).default(20),
      force: z.enum(['true', 'false']).default('false'),
    }).safeParse({ ...req.params, ...(req.query as object) });
    if (!query.success) return reply.status(400).send({ message: '个股资讯查询参数无效' });
    try {
      return reply.send(await getStockNews(query.data.code, { limit: query.data.limit, force: query.data.force === 'true', dbOnline }));
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '个股资讯获取失败' });
    }
  });

  app.get('/api/market-data/news/opinion/status', async (_req, reply) => reply.send({
    configured: Boolean(agentConfig.apiKey),
    currentModel: agentConfig.model,
    availableModels: agentConfig.availableModels,
    inputTiers: MARKET_OPINION_TIERS,
    workflow: ['三类新闻取证', '跨媒体事件去重', '主题与影响链提取', '共识和分歧核验', '风险与验证项'],
    latest: opinionAgent.getLatest(),
  }));

  app.get('/api/market-data/news/opinion/push/status', async (_req, reply) => reply.send(
    opinionPushService?.status() ?? {
      enabled: false,
      configured: false,
      schedules: { morning: '09:00', midday: '12:00', close: '16:00' },
      recipients: 0,
      running: false,
    },
  ));

  app.post('/api/market-data/news/opinion', async (req, reply) => {
    const body = z.object({ model: z.string().optional(), force: z.boolean().default(false) }).safeParse(req.body ?? {});
    if (!body.success) return reply.status(400).send({ message: '市场观点解读参数无效' });
    if (body.data.model && !agentConfig.availableModels.includes(body.data.model)) {
      return reply.status(400).send({ message: '请求的模型不在允许列表中' });
    }
    if (!agentConfig.apiKey) return reply.status(503).send({ message: '请先在服务端配置 AI 模型与密钥' });
    if (!dbOnline) return reply.status(503).send({ message: '数据库不可用，无法整理市场新闻上下文' });
    const wantsStream = req.headers.accept?.includes('application/x-ndjson') ?? false;
    try {
      if (!wantsStream) return reply.send(await opinionAgent.generate(await getMarketOpinionNews(), body.data.model, body.data.force));
      reply.hijack();
      for (const [name, value] of Object.entries(reply.getHeaders())) {
        if (value !== undefined) reply.raw.setHeader(name, value);
      }
      reply.raw.writeHead(200, {
        'Content-Type': 'application/x-ndjson; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        'X-Accel-Buffering': 'no',
      });
      const send = (event: Record<string, unknown>) => {
        if (!reply.raw.destroyed && !reply.raw.writableEnded) reply.raw.write(`${JSON.stringify(event)}\n`);
      };
      send({ type: 'start' });
      try {
        const report = await opinionAgent.generate(await getMarketOpinionNews(), body.data.model, body.data.force, {
          onDelta: (content) => send({ type: 'delta', content }),
          onReasoningDelta: (content) => send({ type: 'reasoning_delta', content }),
        });
        send({ type: 'done', report });
      } catch (error) {
        req.log.error(error);
        send({ type: 'error', message: error instanceof Error ? error.message : '市场观点解读生成失败' });
      } finally {
        reply.raw.end();
      }
      return;
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '市场观点解读生成失败' });
    }
  });

  app.get<{ Params: { code: string }; Querystring: { name?: string } }>(
    '/api/market-data/hot-sectors/:code/constituents',
    async (req, reply) => {
      const input = z.object({
        code: z.string().trim().regex(/^BK\d{4}$/i),
        name: z.string().trim().max(40).optional(),
      }).safeParse({ ...req.params, ...req.query });
      if (!input.success) return reply.status(400).send({ message: '板块代码格式不正确' });
      try {
        return reply.send(await fetchSectorConstituents(
          input.data.code.toUpperCase(),
          input.data.name ?? input.data.code.toUpperCase(),
        ));
      } catch (error) {
        req.log.error(error);
        return reply.status(502).send({ message: error instanceof Error ? error.message : '板块成分股获取失败' });
      }
    },
  );

  app.post('/api/market-data/technical-screen', async (req, reply) => {
    const body = z.object({
      markets: z.array(z.enum(['SH', 'SZ', 'BJ'])).min(1).default(['SH', 'SZ']),
      minChangePct: z.number().min(-30).max(30).default(0),
      maxChangePct: z.number().min(-30).max(30).default(7),
      minAmountYi: z.number().min(0).max(10000).default(1),
      minTurnoverPct: z.number().min(0).max(100).default(0),
      minVolumeRatio: z.number().min(0).max(20).default(0),
      maxAmplitudePct: z.number().min(0).max(100).default(15),
      excludeRiskNames: z.boolean().default(true),
      trend: z.enum(['any', 'bullish', 'aboveMa20', 'bearish']).default('any'),
      returnPeriod: z.union([z.literal(5), z.literal(10), z.literal(20)]).default(20),
      minPeriodReturn: z.number().min(-100).max(1000).default(-30),
      maxPeriodReturn: z.number().min(-100).max(1000).default(30),
      streakDirection: z.enum(['any', 'up', 'down']).default('any'),
      minStreakDays: z.number().int().min(1).max(20).default(2),
      minRsi: z.number().min(0).max(100).default(0),
      maxRsi: z.number().min(0).max(100).default(100),
      kdjSignal: z.enum(['any', 'golden', 'death']).default('any'),
      macdSignal: z.enum(['any', 'golden', 'death']).default('any'),
      limit: z.number().int().min(1).max(200).default(50),
      force: z.boolean().optional(),
      mode: z.enum(['realtime', 'close']).default('realtime'),
    }).safeParse(req.body ?? {});
    if (!body.success
      || body.data.minChangePct > body.data.maxChangePct
      || body.data.minPeriodReturn > body.data.maxPeriodReturn
      || body.data.minRsi > body.data.maxRsi) {
      return reply.status(400).send({ message: '技术筛选条件无效，请检查范围上下限' });
    }
    try {
      const { force, mode, ...criteria } = body.data;
      const useClose = mode === 'close';
      const rows = useClose
        ? await fetchMarketTechnicalRowsFromDb(criteria.markets)
        : await fetchMarketTechnicalRows(force);
      const poolLimit = useClose
        ? Math.min(800, Math.max(criteria.limit * 5, 200))
        : Math.min(160, Math.max(criteria.limit * 3, 80));
      const prefiltered = prefilterMarketTechnicalRows(rows, criteria, poolLimit);
      const enriched = await enrichTechnicalCandidates(prefiltered, useClose ? 'close' : 'realtime');
      const items = filterEnrichedCandidates(enriched, criteria);
      return reply.send({
        items,
        totalScanned: rows.length,
        totalEnriched: enriched.filter((item) => item.indicators != null).length,
        updatedAt: new Date().toISOString(),
      });
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '市场技术筛选失败' });
    }
  });

  app.get('/api/market-data/factor-selection', async (req, reply) => {
    const query = z.object({
      force: z.enum(['true', 'false']).default('false'),
      limit: z.coerce.number().int().min(10).max(200).default(100),
    }).safeParse(req.query);
    if (!query.success) return reply.status(400).send({ message: '因子选股查询参数无效' });
    try {
      return reply.send(await getFactorSelectionHistory(storageConfig.snapshotRoot, {
        force: query.data.force === 'true',
        selectionSize: query.data.limit,
      }));
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({
        message: error instanceof Error ? error.message : '13 因子选股失败',
      });
    }
  });

  app.get('/api/market-data/csi1000-low-pb-selection', async (req, reply) => {
    const query = z.object({
      force: z.enum(['true', 'false']).default('false'),
      limit: z.coerce.number().int().min(10).max(200).default(200),
    }).safeParse(req.query);
    if (!query.success) return reply.status(400).send({ message: '中证1000低PB选股查询参数无效' });
    try {
      return reply.send(await getCsi1000LowPbSelectionHistory(storageConfig.snapshotRoot, {
        force: query.data.force === 'true',
        selectionSize: query.data.limit,
      }));
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({
        message: error instanceof Error ? error.message : '中证1000低PB选股失败',
      });
    }
  });

  app.get<{ Params: { code: string } }>('/api/market-data/stocks/:code/kline', async (req, reply) => {
    const query = z.object({
      period: z.enum(['intraday', 'day', 'week', 'year']).default('day'),
      adjustmentMode: z.enum(['none', 'qfq', 'hfq']).default('qfq'),
      tradeDate: z.string().date().optional(),
      startDate: z.string().date().optional(),
      endDate: z.string().date().optional(),
      fullHistory: z.enum(['true', 'false'])
        .transform((value) => value === 'true')
        .default(false),
      localFirst: z.enum(['true', 'false'])
        .transform((value) => value === 'true')
        .default(false),
    }).safeParse(req.query);
    if (!query.success) return reply.status(400).send({ message: '不支持的 K 线周期' });
    try {
      const security = resolveSecurity(req.params.code);
      const requestedAdjustmentMode: HistoryAdjustmentMode = inferType(security.code, security.market) === 'index'
        ? 'none'
        : query.data.adjustmentMode;
      let source: 'online' | 'database' | 'database+online' = 'online';
      let effectiveAdjustmentMode: HistoryAdjustmentMode = requestedAdjustmentMode;
      let items = query.data.period === 'intraday'
        ? query.data.tradeDate
          ? (await queryMinuteBars(storageConfig.minuteDataRoot, {
            code: req.params.code,
            startDate: query.data.tradeDate,
            endDate: query.data.tradeDate,
            intervalMinutes: 1,
            limit: Math.min(1000, storageConfig.minuteQueryMaxRows),
            includeZeroVolume: true,
          })).items
          : await fetchStockIntraday(req.params.code)
        : [];

      if (query.data.period !== 'intraday') {
        if (query.data.fullHistory) {
          const database = await fetchStockFullHistoryFromDb(
            req.params.code,
            requestedAdjustmentMode,
            { startDate: query.data.startDate, endDate: query.data.endDate },
          );
          effectiveAdjustmentMode = database.adjustmentMode;
          if (database.items.length === 0) {
            items = await fetchStockKline(
              req.params.code,
              query.data.period,
              800,
              requestedAdjustmentMode,
            );
            effectiveAdjustmentMode = requestedAdjustmentMode;
          } else {
            const session = getChinaMarketSession();
            const latestDatabaseDate = database.items.at(-1)?.date;
            const needsOnline = shouldRefreshDailyKline(
              latestDatabaseDate,
              session.tradeDate,
              session.isIntradayUpdateWindow,
            );
            const online = needsOnline
              ? await fetchStockKline(req.params.code, 'day', 30, effectiveAdjustmentMode)
                  .catch(() => [])
              : [];
            const daily = mergeKlinePoints(database.items, online);
            items = query.data.period === 'day'
              ? daily
              : aggregateDailyKlines(daily, query.data.period);
            source = online.length > 0 ? 'database+online' : 'database';
          }
        } else if (query.data.localFirst) {
          const database = await fetchStockFullHistoryFromDb(
            req.params.code,
            requestedAdjustmentMode,
          );
          effectiveAdjustmentMode = database.adjustmentMode;
          if (database.items.length > 0) {
            const daily = database.items.slice(-320);
            items = query.data.period === 'day'
              ? daily
              : aggregateDailyKlines(daily, query.data.period);
            source = 'database';
          } else {
            items = await fetchStockKline(
              req.params.code,
              query.data.period,
              320,
              requestedAdjustmentMode,
            );
            effectiveAdjustmentMode = requestedAdjustmentMode;
          }
        } else {
          items = await fetchStockKline(
            req.params.code,
            query.data.period,
            320,
            requestedAdjustmentMode,
          );
        }
      }
      return reply.send({
        period: query.data.period,
        adjustmentMode: effectiveAdjustmentMode,
        source,
        volumeUnit: 'share',
        items,
      });
    } catch (error) {
      return reply.status(502).send({ message: error instanceof Error ? error.message : 'K 线获取失败' });
    }
  });

  app.get('/api/market-data/minute/catalog', async (_req, reply) => {
    try {
      return reply.send(await getMinuteDataCatalog(storageConfig.minuteDataRoot));
    } catch (error) {
      return reply.status(502).send({ message: error instanceof Error ? error.message : '分钟数据目录读取失败' });
    }
  });

  app.get<{ Params: { code: string } }>('/api/market-data/stocks/:code/minute', async (req, reply) => {
    const security = resolveSecurity(req.params.code);
    if (inferType(security.code, security.market) !== 'stock') {
      return reply.status(422).send({ message: '仅支持股票历史分钟行情' });
    }
    const query = z.object({
      startDate: z.string().date(),
      endDate: z.string().date().optional(),
      interval: z.coerce.number().int().refine(
        (value) => [1, 5, 15, 30, 60, 120].includes(value),
        '不支持的分钟周期',
      ).default(1),
      limit: z.coerce.number().int().min(1).max(storageConfig.minuteQueryMaxRows).default(10000),
      includeZeroVolume: z.enum(['true', 'false']).default('true').transform((value) => value === 'true'),
    }).safeParse(req.query);
    if (!query.success) return reply.status(400).send({ message: '分钟行情查询参数无效' });
    try {
      return reply.send(await queryMinuteBars(storageConfig.minuteDataRoot, {
        code: req.params.code,
        startDate: query.data.startDate,
        endDate: query.data.endDate ?? query.data.startDate,
        intervalMinutes: query.data.interval as 1 | 5 | 15 | 30 | 60 | 120,
        limit: query.data.limit,
        includeZeroVolume: query.data.includeZeroVolume,
      }));
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '历史分钟行情查询失败' });
    }
  });

  app.get<{ Params: { code: string } }>('/api/market-data/stocks/:code/reports', async (req, reply) => {
    try {
      return reply.send({ items: await fetchResearchReports(req.params.code) });
    } catch (error) {
      return reply.status(502).send({ message: error instanceof Error ? error.message : '研报获取失败' });
    }
  });

  app.get<{ Params: { code: string } }>('/api/market-data/stocks/:code/seven-layer', async (req, reply) => {
    try {
      return reply.send(await fetchSevenLayerSnapshot(req.params.code));
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '七层数据源获取失败' });
    }
  });

  app.get<{ Params: { code: string; section: string } }>('/api/market-data/stocks/:code/seven-layer/:section', async (req, reply) => {
    const section = z.enum(['signal', 'capital', 'fundamental', 'announcement', 'news']).safeParse(req.params.section);
    if (!section.success) return reply.status(400).send({ message: '不支持的数据源模块' });
    try {
      return reply.send(await fetchSevenLayerSection(req.params.code, section.data));
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '数据源模块获取失败' });
    }
  });

  app.get<{ Params: { code: string } }>('/api/market-data/stocks/:code/selection-score-context', async (req, reply) => {
    const query = z.object({
      price: z.coerce.number().positive().optional(),
    }).safeParse(req.query);
    if (!query.success) return reply.status(400).send({ message: '评分价格参数无效' });
    try {
      const now = new Date();
      const valuation = await getLatestStockValuation(req.params.code);
      const price = query.data.price ?? valuation?.price ?? null;
      const [fundamental, dividend] = await Promise.all([
        loadTradingLayer(req.params.code, 'fundamental'),
        loadLocalDividendLayer(storageConfig.snapshotRoot, req.params.code, price, now),
      ]);
      return reply.send(extractSelectionScoreContext({
        peTtm: valuation?.peTtm,
        pb: valuation?.pb,
        psTtm: valuation?.psTtm,
        marketCapYi: valuation?.totalMarketCap == null ? null : valuation.totalMarketCap / 100_000_000,
        floatMarketCapYi: valuation?.floatMarketCap == null ? null : valuation.floatMarketCap / 100_000_000,
        source: valuation ? [`本地日线估值（${valuation.tradeDate}）`] : [],
      }, fundamental, dividend));
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '评分基础数据获取失败' });
    }
  });

  app.get('/api/market-data/research-agent/status', async (_req, reply) => reply.send({
    configured: Boolean(agentConfig.apiKey),
    currentModel: agentConfig.model,
    availableModels: agentConfig.availableModels,
    tradingStyles: TRADING_STYLE_DEFINITIONS.map(({ value, label, riskLevel, riskLabel, description }) => ({
      value,
      label,
      riskLevel,
      riskLabel,
      description,
    })),
    minStyles: 1,
    maxStyles: 3,
    workflow: ['全市场环境', '个股多层数据', '消息面交叉验证', '多风格研判', '条件式交易计划', '风险核验'],
  }));

  app.post<{ Params: { code: string } }>('/api/market-data/stocks/:code/research', async (req, reply) => {
    const body = z.object({
      question: z.string().max(1000).optional(),
      model: z.string().optional(),
      styles: z.array(z.enum(TRADING_STYLE_IDS)).min(1).max(3),
    }).safeParse(req.body ?? {});
    if (!body.success) return reply.status(400).send({ message: '请选择 1–3 种交易风格' });
    if (body.data.model && !agentConfig.availableModels.includes(body.data.model)) {
      return reply.status(400).send({ message: '请求的模型不在允许列表中' });
    }
    if (!agentConfig.apiKey) return reply.status(503).send({ message: '请先在服务端配置 AI 模型与密钥' });
    try {
      const now = new Date();
      const quote = await fetchStockQuote(req.params.code);
      const needsSignal = body.data.styles.some((style) => ['growth', 'cycle', 'contrarian', 'limit-up'].includes(style));
      const needsCapital = body.data.styles.some((style) => ['contrarian', 'technical', 'chan', 'trend', 'limit-up'].includes(style));
      const needsFundamental = body.data.styles.some((style) => ['value', 'growth', 'cycle', 'contrarian'].includes(style));
      const needsDividend = body.data.styles.includes('value');
      const needsReports = body.data.styles.some((style) => ['value', 'growth', 'cycle'].includes(style));
      const [daily, weekly, reports, marketContext, marketNews, stockNews, signal, capital, remoteFundamental, localDividend] = await Promise.all([
        fetchStockKline(req.params.code, 'day'),
        fetchStockKline(req.params.code, 'week'),
        needsReports ? loadOptionalResearchReports(req.params.code) : [],
        buildMarketContext(now, { forceRefresh: false }),
        loadLocalMarketNews(dbOnline, now),
        loadRecentStockNews(req.params.code, dbOnline, now),
        needsSignal ? loadTradingLayer(req.params.code, 'signal') : emptyTradingLayer('当前流派未请求事件信号'),
        needsCapital ? loadTradingLayer(req.params.code, 'capital') : emptyTradingLayer('当前流派未请求个股资金层'),
        needsFundamental ? loadTradingLayer(req.params.code, 'fundamental') : emptyTradingLayer('当前流派未请求扩展基础面'),
        needsDividend
          ? loadLocalDividendLayer(storageConfig.snapshotRoot, req.params.code, quote.price, now)
          : emptyTradingLayer('非价值投资派，无需加载分红历史'),
      ]);
      const fundamental = needsDividend
        ? mergeTradingLayers(localDividend, remoteFundamental)
        : remoteFundamental;
      const context = {
        quote,
        daily,
        weekly,
        reports,
        styles: body.data.styles,
        marketContext,
        marketNews: selectOpinionNews(marketNews, now.getTime()).slice(0, 14),
        stockNews,
        marketLayers: { signal, capital, fundamental },
        question: body.data.question,
      };
      const wantsStream = req.headers.accept?.includes('application/x-ndjson') ?? false;
      if (!wantsStream) return reply.send(await agent.research(context, body.data.model));

      reply.hijack();
      for (const [name, value] of Object.entries(reply.getHeaders())) {
        if (value !== undefined) reply.raw.setHeader(name, value);
      }
      reply.raw.writeHead(200, {
        'Content-Type': 'application/x-ndjson; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        'X-Accel-Buffering': 'no',
      });
      const abortController = new AbortController();
      let finished = false;
      const send = (event: Record<string, unknown>) => {
        if (!reply.raw.destroyed && !reply.raw.writableEnded) {
          reply.raw.write(`${JSON.stringify(event)}\n`);
        }
      };
      reply.raw.once('close', () => {
        if (!finished) abortController.abort();
      });
      send({ type: 'start' });
      try {
        const result = await agent.research(context, body.data.model, {
          signal: abortController.signal,
          onDelta: (content) => send({ type: 'delta', content }),
          onReasoningDelta: (content) => send({ type: 'reasoning_delta', content }),
        });
        send({
          type: 'done',
          model: result.model,
          sources: result.sources,
          reasoningSummary: result.reasoningSummary,
        });
      } catch (error) {
        req.log.error(error);
        send({
          type: 'error',
          message: error instanceof Error ? error.message : '智能交易分析失败',
        });
      } finally {
        finished = true;
        if (!reply.raw.writableEnded) reply.raw.end();
      }
      return;
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '智能交易分析失败' });
    }
  });

  app.get('/api/research-snapshots/current', async (_req, reply) => {
    const snapshot = await getCurrentResearchSnapshot(storageConfig.snapshotRoot);
    return reply.send(snapshot ?? { status: 'unavailable' });
  });

  app.get<{ Params: { code: string } }>('/api/research-snapshots/index-constituents/:code', async (req, reply) => {
    const parsed = z.string().regex(/^\d{6}$/).safeParse(req.params.code);
    if (!parsed.success) return reply.status(400).send({ message: '指数代码必须为 6 位数字' });
    try {
      const snapshot = await queryLatestIndexConstituents(storageConfig.snapshotRoot, parsed.data);
      return reply.send(snapshot ?? {
        indexCode: parsed.data,
        indexName: parsed.data,
        constituentDate: '',
        weightDate: null,
        source: '本地研究快照',
        total: 0,
        updatedAt: new Date().toISOString(),
        items: [],
      });
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '指数成分股读取失败' });
    }
  });

  app.get('/api/research-snapshots/freshness', async (_req, reply) => {
    if (!dbOnline || !storageConfig.pool || !storageConfig.config) {
      return reply.status(503).send(dbUnavailable());
    }
    return reply.send(await getResearchSnapshotFreshness(storageConfig.pool, storageConfig.snapshotRoot));
  });

  app.post('/api/research-snapshots/update', async (req, reply) => {
    if (!dbOnline || !storageConfig.pool) {
      return reply.status(503).send(dbUnavailable());
    }
    if (snapshotUpdateInFlight) {
      return reply.status(409).send({ message: '研究快照正在更新，请稍后刷新状态' });
    }
    snapshotUpdateInFlight = (async () => {
      const before = await getResearchSnapshotFreshness(storageConfig.pool!, storageConfig.snapshotRoot);
      const manifest = await buildResearchSnapshot(storageConfig.pool!, storageConfig.config!, {
        root: storageConfig.snapshotRoot,
        onProgress: (message) => req.log.info(`[snapshot] ${message}`),
      });
      const verification = await verifyCurrentResearchSnapshot(storageConfig.snapshotRoot);
      const after = await getResearchSnapshotFreshness(storageConfig.pool!, storageConfig.snapshotRoot);
      return { before, manifest, verification, after };
    })();
    try {
      return reply.send(await snapshotUpdateInFlight);
    } finally {
      snapshotUpdateInFlight = null;
    }
  });

  app.get('/api/research-snapshots/scan', async (req, reply) => {
    const parsed = z.object({
      startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
      endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
      fields: z.string().max(512).default('market,symbol,tradeDate,close'),
      markets: z.string().max(64).optional(),
      symbols: z.string().max(5000).optional(),
      limit: z.coerce.number().int().min(1)
        .max(storageConfig.researchQueryMaxRows)
        .default(Math.min(1000, storageConfig.researchQueryMaxRows)),
    }).safeParse(req.query);
    if (
      !parsed.success
      || parsed.data.startDate > parsed.data.endDate
      || daysBetween(parsed.data.startDate, parsed.data.endDate) > 366
    ) {
      return reply.status(400).send(
        apiError(ErrorCodes.VALIDATION_ERROR, '研究查询参数无效', parsed.success ? [] : parsed.error.issues),
      );
    }
    try {
      return reply.send(await queryResearchSnapshot(storageConfig.snapshotRoot, {
        startDate: parsed.data.startDate,
        endDate: parsed.data.endDate,
        fields: parsed.data.fields.split(',').map((field) => field.trim()).filter(Boolean),
        markets: parsed.data.markets?.split(',').map((market) => market.trim()).filter(Boolean),
        symbols: parsed.data.symbols?.split(',').map((symbol) => symbol.trim()).filter(Boolean),
        limit: parsed.data.limit,
      }));
    } catch (error) {
      req.log.error(error);
      return reply.status(503).send({
        message: error instanceof Error ? error.message : '研究快照查询失败',
      });
    }
  });

  if (!dbOnline) {
    const stub = async () => { throw { statusCode: 503, ...dbUnavailable() }; };
    app.get('/api/instruments/:id/candles', stub);
    app.get('/api/market-data/freshness', stub);
    app.get('/api/market-data/providers', stub);
    app.post('/api/market-data/index-datasets/update', stub);
    return;
  }

  app.post('/api/market-data/index-datasets/update', async (req, reply) => {
    const body = z.object({
      group: z.enum(['cn-index', 'us-index']),
      force: z.boolean().optional(),
    }).safeParse(req.body ?? {});
    if (!body.success) return reply.status(400).send({ message: '请指定 group: cn-index 或 us-index' });
    try {
      return reply.send(await updateIndexDatasets(body.data.group, tencentProvider, new Date(), { force: body.data.force }));
    } catch (error) {
      req.log.error(error);
      return reply.status(502).send({ message: error instanceof Error ? error.message : '指数数据集更新失败' });
    }
  });

  // GET /api/instruments/:id/candles — Daily candles for synced data
  app.get<{ Params: { id: string } }>(
    '/api/instruments/:id/candles',
    async (req, reply) => {
      const inst = await getInstrument(req.params.id);
      if (!inst) {
        return reply.status(404).send(
          apiError(ErrorCodes.INSTRUMENT_NOT_FOUND, '交易标的不存在'),
        );
      }

      const parsed = candlesQuerySchema.safeParse(req.query);
      if (!parsed.success) {
        return reply.status(400).send(
          apiError(ErrorCodes.VALIDATION_ERROR, '参数校验失败', parsed.error.issues),
        );
      }

      const {
        startDate, endDate, adjustmentMode, offset, limit,
      } = parsed.data;
      if (storageConfig.historyReadMode !== 'legacy' && inst.instrumentKey != null) {
        const history = await getHistoryDailyBars(
          inst.instrumentKey,
          adjustmentMode === 'none'
            ? { startDate, endDate, offset, limit }
            : { startDate, endDate, offset: 0, limit: 10000 },
        );
        if (history.total > 0) {
          if (adjustmentMode === 'none') {
            return reply.send({
              items: history.data,
              total: history.total,
              storage: 'history-v2',
              adjustmentMode,
              factorVersion: null,
              adjustmentQualityStatus: 'pass',
              adjustmentWarnings: [],
            });
          }
          const adjustment = await getPublishedHistoryAdjustment(
            inst.instrumentKey,
            inst.id,
            adjustmentMode,
          );
          if (!adjustment || adjustment.factors.length === 0) {
            return reply.status(409).send(
              apiError(ErrorCodes.VALIDATION_ERROR, '该证券暂无已发布的复权参数'),
            );
          }
          const adjusted = applyHistoryAdjustment(
            history.data,
            adjustment.factors,
            adjustment.overrides,
            adjustmentMode as Exclude<HistoryAdjustmentMode, 'none'>,
          ).filter((bar) => (
            (!startDate || bar.tradeDate >= startDate)
            && (!endDate || bar.tradeDate <= endDate)
          ));
          return reply.send({
            items: adjusted.slice(offset, offset + limit),
            total: adjusted.length,
            storage: 'history-v2',
            adjustmentMode,
            factorVersion: adjustment.factorVersion,
            adjustmentQualityStatus: adjustment.warnings.length > 0 ? 'warning' : 'pass',
            adjustmentWarnings: adjustment.warnings,
          });
        }
      }
      if (storageConfig.historyReadMode === 'v2') {
        return reply.status(404).send(
          apiError(ErrorCodes.INSTRUMENT_NOT_FOUND, 'v2 行情库中不存在该证券数据'),
        );
      }
      if (adjustmentMode !== 'none') {
        return reply.status(409).send(
          apiError(ErrorCodes.VALIDATION_ERROR, '旧行情路径不支持按需复权，请切换到 v2'),
        );
      }
      const result = await getDailyCandles(req.params.id, {
        startDate,
        endDate,
        offset,
        limit,
      });
      return reply.send({
        items: result.data,
        total: result.total,
        storage: 'legacy',
        adjustmentMode: 'none',
        factorVersion: null,
        adjustmentQualityStatus: 'pass',
        adjustmentWarnings: [],
      });
    },
  );

  // GET /api/market-data/freshness — Overall data freshness summary
  app.get('/api/market-data/freshness', async (_req, reply) => {
    const freshness = await getDataFreshness();
    return reply.send(freshness);
  });

  // GET /api/market-data/providers — Available data provider IDs and capabilities
  app.get('/api/market-data/providers', async (_req, reply) => {
    const providers = listProviders();
    const data = providers.map((p) => ({
      id: p.id,
      name: p.name,
      type: p.type,
      capabilities: p.getCapabilities(),
    }));
    return reply.send(data);
  });
}

function daysBetween(startDate: string, endDate: string): number {
  return Math.floor(
    (Date.parse(`${endDate}T00:00:00Z`) - Date.parse(`${startDate}T00:00:00Z`))
    / 86_400_000,
  );
}

function isRecentNews(publishedAt: string, now: Date, lookbackDays: number): boolean {
  const timestamp = Date.parse(publishedAt);
  return Number.isFinite(timestamp)
    && timestamp >= now.getTime() - lookbackDays * 86_400_000
    && timestamp <= now.getTime() + 5 * 60_000;
}
